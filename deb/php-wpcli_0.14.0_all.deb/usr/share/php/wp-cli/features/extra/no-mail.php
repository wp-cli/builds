<?php

function wp_mail() {
	// do nothing
}

