<?php

define( 'WP_CLI_ROOT', 'phar://wp-cli.phar' );

include WP_CLI_ROOT . '/php/wp-cli.php';

