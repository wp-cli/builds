<?php

namespace WP_CLI\Iterators;

class Exception extends \RuntimeException {}

