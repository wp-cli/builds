<?php

require_once getcwd() . '/vendor/autoload.php';
require_once getcwd() . '/php/utils.php';

